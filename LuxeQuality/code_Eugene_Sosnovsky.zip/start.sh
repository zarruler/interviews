#!/bin/bash

echo "executing: # docker-compose up -d"
echo ""
docker stop $(docker ps -a -q)
USER=www-data docker-compose up -d