<?php
return [
    'process_on' => 'process running',
    'process_off'=> 'process not running',
    'commands'   => 'available commands:',
];