<?php
return [
    'command_absent' => 'Cannot find command',
    'incorrect_input' => 'Script expects 2 params: command and process name',
];